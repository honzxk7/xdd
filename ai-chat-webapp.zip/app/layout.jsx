import './globals.css'

export const metadata = {
  title: 'AI Chat on Your Site',
  description: 'A simple chat UI that talks to OpenAI, ready for Vercel deploy.'
}

export default function RootLayout({ children }) {
  return (
    <html lang="cs">
      <body className="bg-slate-50 text-slate-900">
        <main className="min-h-screen flex items-center justify-center p-4">
          <div className="w-full max-w-3xl">{children}</div>
        </main>
      </body>
    </html>
  )
}