'use client'

import { useState, useRef } from 'react'

export default function Page() {
  const [messages, setMessages] = useState([
    { role: 'assistant', content: 'Ahoj — jsem tvůj AI chat. Jak ti můžu pomoct?' }
  ])
  const [input, setInput] = useState('')
  const [loading, setLoading] = useState(false)
  const messagesEndRef = useRef(null)

  function scrollToBottom(){
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  async function sendMessage(e) {
    e?.preventDefault()
    if (!input.trim()) return
    const userMsg = { role: 'user', content: input.trim() }
    setMessages(prev => [...prev, userMsg])
    setInput('')
    setLoading(true)

    try {
      const res = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: [...messages, userMsg] })
      })
      if (!res.ok) throw new Error('Serverová chyba')
      const data = await res.json()
      setMessages(prev => [...prev, { role: 'assistant', content: data.reply }])
      setTimeout(scrollToBottom, 50)
    } catch (err) {
      setMessages(prev => [...prev, { role: 'assistant', content: 'Došlo k chybě: ' + String(err) }])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="bg-white shadow-md rounded-2xl overflow-hidden">
      <header className="px-6 py-4 border-b">
        <h1 className="text-xl font-semibold">Tvůj AI Chat</h1>
        <p className="text-sm text-slate-500">Chat založený na OpenAI — hostováno na Vercel.</p>
      </header>

      <section className="p-6 h-[60vh] overflow-auto" id="chat-window">
        <div className="space-y-4">
          {messages.map((m, i) => (
            <div key={i} className={`flex ${m.role === 'user' ? 'justify-end' : 'justify-start'}`}>
              <div className={`max-w-[80%] px-4 py-2 rounded-lg ${m.role === 'user' ? 'bg-blue-600 text-white' : 'bg-slate-100 text-slate-900'}`}>
                <div className="whitespace-pre-wrap">{m.content}</div>
              </div>
            </div>
          ))}
          <div ref={messagesEndRef} />
        </div>
      </section>

      <form onSubmit={sendMessage} className="px-6 py-4 border-t flex gap-3 items-center">
        <input
          value={input}
          onChange={e => setInput(e.target.value)}
          placeholder={loading ? 'Čekej...' : 'Napiš zprávu...'}
          className="flex-1 rounded-lg border px-4 py-2 focus:outline-none"
          disabled={loading}
        />
        <button className="bg-blue-600 text-white px-4 py-2 rounded-lg" disabled={loading}>{loading ? 'Posílám…' : 'Odeslat'}</button>
      </form>
    </div>
  )
}