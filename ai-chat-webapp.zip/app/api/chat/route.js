import { NextResponse } from 'next/server'

export async function POST(request) {
  try {
    const body = await request.json()
    const messages = body.messages || []

    if (!process.env.OPENAI_API_KEY) {
      return NextResponse.json({ error: 'No API key configured' }, { status: 500 })
    }

    const payload = {
      model: 'gpt-4o-mini',
      messages: messages.map(m => ({ role: m.role, content: m.content })),
      temperature: 0.2,
      max_tokens: 800
    }

    const resp = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${process.env.OPENAI_API_KEY}`
      },
      body: JSON.stringify(payload)
    })

    if (!resp.ok) {
      const errText = await resp.text()
      return NextResponse.json({ error: errText }, { status: resp.status })
    }

    const result = await resp.json()
    const reply = result.choices?.[0]?.message?.content || 'Žádná odpověď od modelu.'

    return NextResponse.json({ reply })
  } catch (err) {
    return NextResponse.json({ error: String(err) }, { status: 500 })
  }
}