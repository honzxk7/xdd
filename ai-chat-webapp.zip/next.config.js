module.exports = {
  reactStrictMode: true,
  experimental: {
    appDir: true
  }
}