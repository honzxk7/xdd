# AI Chat Web App — Next.js + Vercel

## Co to dělá
Jednoduché chatovací rozhraní které posílá zprávy na serverovou route `/api/chat`, která přeposílá požadavky do OpenAI. Je připravené pro nasazení na Vercel.

## Kroky k rychlému nasazení
1. Vytvoř nový GitHub repo a nahraj tyto soubory.
2. Vytvoř účet na Vercel a importuj repo (Import Project).
3. V nastavení projektu ve Vercel přidej environment variablu `OPENAI_API_KEY` s tvým OpenAI API klíčem.
4. Deploy — Vercel automaticky spustí build (`npm run build`).

## Poznámky k API klíči a bezpečnosti
- Nikdy nevkládej klíč přímo do frontendu. Drž ho v serverových env proměnných.
- Pokud budeš sbírat citlivá data, uprav text souhlasu s GDPR a ulož data bezpečně.

## Přizpůsobení
- Změň systémový prompt nebo počáteční zprávy v `app/page.jsx` nebo v `app/api/chat/route.js`.
